<?php
header ("Location: ../");
?>