<?php
if(!defined('INITIALIZED'))
	exit;

$ok = "/[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,4}/";
echo '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
$email = trim($_REQUEST['email']);
if(empty($email))
{
	echo '<font color="red">xxx</font>';
	exit;
}
if(strlen($email) < 255)
{
	if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
		if($config['site']['one_email'])
		{
			$email_db = new Account();
			$email_db->findByEMail($email);
			if($email_db->isLoaded())
				echo '<font color="red">xxx</font>';
			else
				echo '<font color="green">ok</font>';
		}
		else
			echo '<font color="green">ok</font>';
	}
	else
		echo '<font color="red">xxx</font>';
}
else
	echo '<font color="red">xxx</font>';
exit;
