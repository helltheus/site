<?php
if(!defined('INITIALIZED'))
	exit;

echo '<?xml version="1.0" encoding="utf-8" standalone="yes"?>';
$account = strtoupper(trim($_REQUEST['account']));
if(empty($account))
{
	echo 'xxx';
	exit;
}
if(strlen($account) < 32)
{
	if(!check_account_name($account))
	{
		echo 'xxx';
		exit;
	}
	$account_db = new Account();
	$account_db->find($account);
	if($account_db->isLoaded())
		echo 'xxx';
	else
		echo 'ok';
}
else
	echo 'xxx';
exit;
