<?php
$options[130114]['name'] = 'Buy 300 premium points';
$options[130114]['payalogue_id'] = 119754;
$options[130114]['price_id'] = 130114 ;
$options[130114]['price_key'] = 'e4ca3dbd15e6b8703eecd2342cd95b83';
$options[130114]['points'] = 300;

$options[130124]['name'] = 'Buy 600 premium points';
$options[130124]['payalogue_id'] = 119764;
$options[130124]['price_id'] = 130124;
$options[130124]['price_key'] = '15cb04c886a16219c3b04342aeaa7330';
$options[130124]['points'] = 600;

$options[130134]['name'] = 'Buy 900 premium points';
$options[130134]['payalogue_id'] = 119774;
$options[130134]['price_id'] = 130134;
$options[130134]['price_key'] = 'e7a0f802dfca4f03e40aa1a1ff58337f';
$options[130134]['points'] = 900;